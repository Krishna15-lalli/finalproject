package com.hcl.cap.entity;

public enum Messages {

	SUCCESS, FAILURE
}
