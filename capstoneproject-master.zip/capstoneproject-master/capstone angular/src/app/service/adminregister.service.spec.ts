import { TestBed } from '@angular/core/testing';
// import {UserService} from
// describe('AdminregisterService', () => {
//   let service: AdminregisterService;

//   beforeEach(() => {
//     TestBed.configureTestingModule({});
//     service = TestBed.inject(LoginUserService);
//   });

//   it('should be created', () => {
//     expect(service).toBeTruthy();
//   });
// });
import { UserService } from './user.service';

describe('UserService', () => {
  let service: UserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(UserService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

