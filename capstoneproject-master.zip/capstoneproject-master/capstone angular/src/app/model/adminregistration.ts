export interface adminregister
  {
    firstname: string,
    lastname: string,
    email: string,
    phone: string,
    address: string,
    password: string,
    confirm_password: string
 }