export interface AdminDetail {
    email: string,
    password: string
 }