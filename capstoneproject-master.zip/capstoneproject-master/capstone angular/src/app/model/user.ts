export interface LoginUser {
   email: string,
   password: string
}